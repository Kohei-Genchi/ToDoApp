<?php

namespace Illuminate\Notifications\Slack\Contracts;

use Illuminate\Contracts\Support\Arrayable;

interface ElementContract extends Arrayable
{
    //
}
