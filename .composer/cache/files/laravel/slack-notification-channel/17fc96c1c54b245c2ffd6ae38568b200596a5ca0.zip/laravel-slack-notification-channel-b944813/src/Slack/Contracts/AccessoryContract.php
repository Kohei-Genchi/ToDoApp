<?php

namespace Illuminate\Notifications\Slack\Contracts;

interface AccessoryContract extends ElementContract
{
    //
}
